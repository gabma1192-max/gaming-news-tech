
import NewsCard from "../components/NewsCard.jsx";

const news = [
  {
    title: "New GPU Released",
    description: "The latest GPU generation brings huge performance improvements."
  },
  {
    title: "Major Game Launch",
    description: "A new open-world RPG has just launched and gamers love it."
  },
  {
    title: "AI in Gaming",
    description: "Artificial intelligence is transforming modern video games."
  }
];

function Home() {
  return (
    <div className="container">
      <h2>Latest News</h2>
      <div className="grid">
        {news.map((item, i) => (
          <NewsCard key={i} title={item.title} description={item.description} />
        ))}
      </div>
    </div>
  );
}

export default Home;
