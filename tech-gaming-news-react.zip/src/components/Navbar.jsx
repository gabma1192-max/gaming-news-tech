
function Navbar() {
  return (
    <div className="navbar">
      Tech & Gaming News
    </div>
  );
}

export default Navbar;
